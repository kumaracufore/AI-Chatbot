from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
import json
from datetime import datetime
import os
from langchain.prompts import PromptTemplate
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
import PyPDF2
import time
import sys
from langchain.chains import ConversationalRetrievalChain
from langchain_huggingface import HuggingFaceEndpoint
from langchain_huggingface import HuggingFaceEmbeddings
import re
from flask import jsonify
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Tuple
import threading


@dataclass
class ConversationState:
    """Tracks the state of a conversation."""

    flow: str = "general"
    step: int = 0
    data: dict = field(default_factory=dict)


def parse_power_requirements(query: str) -> dict:
    """Parse power values from query string"""
    power_info = {"kw": 0, "watts": 0, "amps_240v": 0, "hp": 0}

    kw_match = re.search(r"(\d+(?:\.\d+)?)\s*kw", query.lower())
    watts_match = re.search(r"(\d+)\s*w(?:att)?s?", query.lower())
    amps_match = re.search(r"(\d+)\s*amps?", query.lower())
    hp_match = re.search(r"(\d+(?:\.\d+)?)\s*hp", query.lower())

    if kw_match:
        power_info["kw"] = float(kw_match.group(1))
    if watts_match:
        power_info["watts"] = float(watts_match.group(1))
    if amps_match:
        power_info["amps_240v"] = float(amps_match.group(1))
    if hp_match:
        power_info["hp"] = float(hp_match.group(1))

    return power_info


def calculate_total_power(power_info: dict) -> float:
    """Calculate total power requirement in KW"""
    total_kw = power_info["kw"]
    total_kw += power_info["watts"] / 1000
    total_kw += (power_info["amps_240v"] * 240 * 0.8) / 1000  # 0.8 power factor
    total_kw += power_info["hp"] * 0.746  # Convert HP to KW
    return total_kw


def get_product_link(model_no: str) -> str:
    """Get the product page link for a PC model"""
    if model_no.startswith("EU"):
        return f"https://pc-store.com/series/eu/{model_no}"
    elif model_no.startswith("GP"):
        return f"https://pc-store.com/series/gp/{model_no}"
    elif model_no.startswith("RY"):
        return f"https://pc-store.com/series/ry/{model_no}"
    return "https://pc-store.com/products"


def format_recommendations(
    total_kw: float, recommendations: list, base_kw: float = 0, cpu_cores: float = 0
) -> str:
    """Format PC recommendations"""
    if not recommendations:
        return (
            "I apologize, but we don't have PCs that meet your computing requirements."
        )

    # Calculate total with 20% margin
    total_with_margin = total_kw * 1.2

    response = [f"Based on your total computing requirement of {total_kw:.1f} KW:"]
    if base_kw > 0:
        response.append(f"• Base load: {base_kw:.1f} KW")
    if cpu_cores > 0:
        response.append(f"• CPU cores: {cpu_cores} cores")
    response.append(f"• Required capacity with 20% margin: {total_with_margin:.1f} KW")

    response.append("\nRecommended PC Series:")

    # Similar structure to generator recommendations, but for PCs
    suitable_models = []
    for pc in recommendations:
        power = pc.get("kw", pc.get("power", 0))
        if power >= total_kw:
            suitable_models.append(
                {
                    "model_no": pc.get("model_no", "Unknown"),
                    "kw": power,
                    "cpu_cores": pc.get("cpu_cores", 0),
                    "ram_gb": pc.get("ram_gb", 0),
                    "gpu": pc.get("gpu", "Integrated"),
                }
            )
            if len(suitable_models) == 2:
                break

    for i, pc in enumerate(suitable_models, 1):
        model_no = pc["model_no"]
        price_info = get_model_price(model_no)
        product_link = get_product_link(model_no)

        response.append(f"\nOption {i}:")
        specs = [
            f"• Model: {model_no}",
            f"• Power Consumption: {pc['kw']} KW",
            f"• CPU Cores: {pc['cpu_cores']}",
            f"• RAM: {pc['ram_gb']} GB",
            f"• GPU: {pc['gpu']}",
        ]

        if price_info:
            # Similar pricing logic to generators
            if price_info["usd"] is not None:
                usd_regular = price_info["usd"]
                usd_discounted = usd_regular * (
                    1 - price_info["discount"]["percentage"] / 100
                )
                specs.extend(
                    [
                        f"• Price USD: ${usd_regular:,}",
                        f"• Price USD with {price_info['discount']['percentage']}% discount: ${usd_discounted:,.2f}",
                    ]
                )

        specs.append(f"\nProduct page: {product_link}")
        response.append("\n".join(specs))

    return "\n".join(response)


def get_shipping_weight(model: str) -> int:
    """Get shipping weight for a Power Equipment model"""
    # Determine which series the model belongs to
    if model.startswith("EU"):
        series = "EU"
    elif model.startswith("GP"):
        series = "GP"
    elif model.startswith("RY"):
        series = "RY"
    else:
        return 0

    # Load specifications from JSON
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        json_path = os.path.join(current_dir, "json", f"{series}-Specification.json")

        if os.path.exists(json_path):
            with open(json_path, "r") as f:
                specs = json.load(f)
                if "models" in specs:
                    for model_spec in specs["models"]:
                        if model_spec["model_no"].replace(" ", "") == model:
                            return model_spec.get("shipping_weight_lbs", 0)
    except Exception as e:
        print(f"Error loading shipping weight: {str(e)}")

    return 0


def load_series_specifications(series: str) -> dict:
    """Load specifications for a Power Equipment series"""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        json_path = os.path.join(
            current_dir, "json", f"{series.upper()}-Specification.json"
        )

        if os.path.exists(json_path):
            with open(json_path, "r") as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading specifications for {series}: {str(e)}")

    return {}


def format_model_details(model_specs: dict) -> str:
    """Format details for a specific model"""
    response = [f"Model {model_specs['model_no']} Specifications:"]

    # Map of technical terms to more readable names
    spec_names = {
        "kw": "Continuous Power",
        "surge_kw": "Surge Power",
        "rpm": "Operating RPM",
        "shipping_weight_lbs": "Shipping Weight",
        "voltage": "Voltage",
        "amps": "Full Load Amps",
        "phase": "Phase",
        "poles": "Number of Poles",
        "welder_receipt_voltage": "Welder Receipt Voltage",
        "hp_50_load": "50% Load HP",
        "hp_100_load": "100% Load HP",
        "connection": "Connection Type",
        "internal_rpm": "Internal RPM",
    }

    # Add each specification if it exists
    for key, display_name in spec_names.items():
        if key in model_specs and model_specs[key] is not None:
            value = model_specs[key]
            # Add appropriate units
            if "kw" in key:
                value = f"{value} KW"
            elif key == "shipping_weight_lbs":
                value = f"{value} lbs"
            elif key == "rpm" or key == "internal_rpm":
                value = f"{value} RPM"
            elif key == "amps":
                value = f"{value} A"
            elif key == "voltage":
                value = f"{value}V"
            elif "hp" in key:
                value = f"{value} HP"
            response.append(f"• {display_name}: {value}")

    # Add price information if available
    price_info = get_model_price(model_specs["model_no"])
    if price_info:
        response.append(f"• Price USD: ${price_info['usd']:,}")
        response.append(f"• Price CAD: ${price_info['cad']:,}")

    # Add product page link
    product_link = get_product_link(model_specs["model_no"])
    response.append(f"\nProduct page: {product_link}")

    return "\n".join(response)


def format_features(features: dict) -> str:
    """Format features for a series"""
    if not features:
        return "Features not available for this series"

    response = [f"Efficiency: {features['efficiency']}", "\nKey Features:"]
    for feature in features["features"]:
        response.append(f"• {feature}")
    return "\n".join(response)


class ConversationHandler:
    """Unified conversation handler that manages all flows"""

    def __init__(self):
        self.intents = self.load_intents()

    def load_intents(self) -> dict:
        """Load and return the intent patterns dictionary"""
        return {
            "power_calculation": self.get_power_calculation_patterns(),
            "model_info": self.get_model_info_patterns(),
            "pricing": self.get_pricing_patterns(),
            "features": self.get_feature_patterns(),
            "greeting": self.get_greeting_patterns(),
            "farewell": self.get_farewell_patterns(),
        }

    def get_power_calculation_patterns(self) -> list:
        return [
            "calculate power",
            "power calculator",
            "power needs",
            "what size Power Equipment",
            "how much power",
            "Power Equipment size",
            "power requirement",
            "need Power Equipment for",
            "power for",
            "watts",
            "kw",
            "kilowatts",
            "amps",
            "amperage",
        ]

    def get_model_info_patterns(self) -> list:
        return [
            "tell me about",
            "show me",
            "specifications",
            "specs",
            "details about",
            "information about",
            "model",
            "series",
        ]

    def get_pricing_patterns(self) -> list:
        return [
            "price",
            "cost",
            "how much is",
            "pricing for",
            "price of",
            "cost of",
            "quote for",
            "quote on",
        ]

    def get_feature_patterns(self) -> list:
        return [
            "features",
            "what features",
            "capabilities",
            "what can",
            "feature list",
            "key features",
            "benefits",
            "advantages",
        ]

    def get_greeting_patterns(self) -> list:
        return [
            "hi",
            "hello",
            "hey",
            "greetings",
            "good morning",
            "good afternoon",
            "good evening",
        ]

    def get_farewell_patterns(self) -> list:
        return [
            "bye",
            "goodbye",
            "see you",
            "farewell",
            "thanks",
            "thank you",
            "exit",
            "quit",
        ]

        self.states = {}  # session_id -> ConversationState

    def match_intent(self, query: str) -> tuple[str, float]:
        """Match query to intent using fuzzy matching"""
        query = query.lower().strip()
        best_match = (None, 0)

        # Check for direct power values first
        if re.search(r"\d+\s*(?:kw|kilowatt|w|watt|amp|hp)", query):
            return "power_calculation", 1.0

        # Check for pricing queries with model numbers
        if re.search(
            r"(?:price|cost|how much|pricing)\s+(?:of|for)?\s*(?:eu|gp|ry)\s*\d+",
            query,
            re.I,
        ):
            return "pricing", 1.0

        # Check for model numbers in pricing context
        if re.search(r"(?:eu|gp|ry)\s*\d+", query, re.I) and any(
            word in query.lower() for word in ["price", "cost", "how much", "pricing"]
        ):
            return "pricing", 1.0

        # Check for model numbers without pricing context
        if re.search(r"(?:eu|gp|ry)\s*\d+", query, re.I):
            return "model_info", 1.0

        # Check other intents
        for intent, patterns in self.intents.items():
            for pattern in patterns:
                if pattern in query:
                    return intent, 1.0

            # Calculate word overlap for fuzzy matching
            query_words = set(query.split())
            pattern_words = set(pattern.split())
            common_words = query_words & pattern_words

            if common_words:
                score = len(common_words) / max(len(query_words), len(pattern_words))
                if score > best_match[1]:
                    best_match = (intent, score)

        return best_match if best_match[1] > 0.3 else (None, 0)

    def handle_conversation(
        self, query: str, chat_history: list = None, session_id: str = "default"
    ) -> str:
        """Main conversation handler"""
        # Get or create conversation state
        state = self.states.get(session_id, ConversationState())
        self.states[session_id] = state

        # Handle active flows first
        if state.flow != "general":
            response = self.handle_active_flow(query, state, chat_history)
            if response:
                return response

        # Match new intent
        intent, confidence = self.match_intent(query)

        if not intent:
            return self.handle_unknown_query()

        # Handle based on intent
        if intent == "power_calculation":
            return self.handle_power_calculation(query, state)

        elif intent == "model_info":
            return self.handle_model_info(query, state)

        elif intent == "pricing":
            return self.handle_pricing(query, state)

        elif intent == "features":
            return self.handle_features(query, state)

        elif intent == "greeting":
            return self.handle_greeting()

        elif intent == "farewell":
            return self.handle_farewell(session_id)

        return self.handle_unknown_query()

    def handle_active_flow(
        self, query: str, state: ConversationState, chat_history: list = None
    ) -> str:
        """Handle ongoing conversation flows"""
        if state.flow == "power_calculation":
            if state.step == 1:  # Series selection
                series = query.upper()[:2]
                if series in ["EU", "GP", "RY"]:
                    state.data["series"] = series
                    state.step = 2
                    if series == "EU":
                        return "What is your total Amps @ 120 Volts (Appliances)?"
                    else:
                        return "Average House (5KW)? (yes/no)"
                return "Please select a valid series (EU, GP, or RY)"

            elif state.step == 2:  # Power requirement
                try:
                    series = state.data.get("series")
                    if series == "EU":
                        # Handle 120V amps
                        amps_120v = float(query.strip())
                        state.data["amps_120v"] = amps_120v
                        state.step = 3
                        return "What is your total Amps @ 240 Volts (Appliances)?"
                    else:
                        # Handle Average House response
                        answer = query.lower().strip()
                        if answer in ["yes", "y"]:
                            state.data["house_kw"] = 5.0
                        elif answer in ["no", "n"]:
                            state.data["house_kw"] = 0.0
                        else:
                            return "Please answer 'yes' or 'no'"
                        state.step = 3
                        return "Average Small Shop (10KW)? (yes/no)"
                except ValueError:
                    return "Please enter a valid response"

            elif state.step == 3:  # Small Shop or 240V
                try:
                    series = state.data.get("series")
                    if series == "EU":
                        # Handle 240V amps
                        amps_240v = float(query.strip())
                        state.data["amps_240v"] = amps_240v
                        state.step = 4
                        return "What is your total HP in motors? (Enter 0 if none)"
                    else:
                        # Handle Average Small Shop response
                        answer = query.lower().strip()
                        if answer in ["yes", "y"]:
                            state.data["shop_kw"] = 10.0
                        elif answer in ["no", "n"]:
                            state.data["shop_kw"] = 0.0
                        else:
                            return "Please answer 'yes' or 'no'"
                        state.step = 4
                        return "What is your total HP in motors? (Enter 0 if none)"
                except ValueError:
                    return "Please enter a valid response"

            elif state.step == 4:  # Motor HP for all series
                try:
                    hp = float(query.strip())
                    series = state.data.get("series")

                    if series == "EU":
                        # Calculate total power for EU series
                        amps_120v = state.data.get("amps_120v", 0)
                        amps_240v = state.data.get("amps_240v", 0)
                        pw_220w = (amps_120v * 120 * 0.8) / 1000  # 0.8 power factor
                        kw_240v = (amps_240v * 240 * 0.8) / 1000  # 0.8 power factor
                        motor_kw = hp * 0.746  # Convert HP to KW
                        total_kw = pw_220w + kw_240v + motor_kw
                        base_kw = pw_220w + kw_240v
                    else:
                        # Calculate total power for GP/RY series
                        house_kw = state.data.get("house_kw", 0)
                        shop_kw = state.data.get("shop_kw", 0)
                        base_kw = house_kw + shop_kw
                        motor_kw = hp * 0.746  # Convert HP to KW
                        total_kw = base_kw + motor_kw

                    # Find suitable Power Equipments
                    suitable_models = find_suitable_power_equipment(total_kw)
                    if not suitable_models:
                        return f"I apologize, but I couldn't find any Power Equipments that meet your power requirement of {total_kw:.1f} KW. Please contact our sales team for a custom solution."

                    # Prepare response
                    response = f"Based on your requirements, here's what you need:\n\n"
                    if series == "EU":
                        response += f"• 120V Load: {pw_220w:.1f} KW\n"
                        response += f"• 240V Load: {kw_240v:.1f} KW\n"
                    else:
                        response += f"• House Load: {house_kw:.1f} KW\n"
                        response += f"• Additional Load: {shop_kw:.1f} KW\n"
                    response += f"• Motor Load ({hp} HP): {motor_kw:.1f} KW\n"
                    response += f"• Total Power Required: {total_kw:.1f} KW\n"
                    response += f"• Recommended Capacity (with 20% safety margin): {total_kw * 1.2:.1f} KW\n\n"

                    # First try models from the selected series
                    series_models = [
                        m for m in suitable_models if m["model_no"].startswith(series)
                    ]
                    if series_models:
                        response += f"Here are the {series} Series models I recommend for you:\n\n"
                        for model in series_models[:2]:
                            response += f"✦ {model['model_no']} Power Equipment:\n"
                            response += f"  • Continuous Power: {model['kw']} KW\n"
                            response += f"  • Surge Capacity: {model.get('surge', model.get('surge_kw', model['kw'] * 2))} KW (perfect for motor startup)\n"
                            response += (
                                f"  • Operating Speed: {model.get('rpm', 1800)} RPM\n"
                            )
                            response += f"  • Full Load Capacity: {model.get('amps', 0)} Amps\n\n"

                            # Add pricing information
                            price_info = get_model_price(model["model_no"])
                            if price_info:
                                response += format_pricing(price_info)

                            response += "  Each Power Equipment includes:\n"
                            response += "  • Portable Shaft\n"
                            response += "  • Heavy-duty trailer\n"
                            response += "  • 10 ft cord with Anderson connector\n\n"

                    # If no models in selected series, suggest alternatives
                    if not series_models:
                        response += f"Your power requirement of {total_kw:.1f} KW exceeds the {series} series capacity.\n"
                        response += "Here are some alternative recommendations that will better meet your needs:\n\n"
                        for model in suitable_models[:2]:
                            response += f"✦ {model['model_no']} Power Equipment:\n"
                            response += f"  • Continuous Power: {model['kw']} KW\n"
                            response += f"  • Surge Capacity: {model.get('surge', model.get('surge_kw', model['kw'] * 2))} KW (perfect for motor startup)\n"
                            response += (
                                f"  • Operating Speed: {model.get('rpm', 1800)} RPM\n"
                            )
                            response += f"  • Full Load Capacity: {model.get('amps', 0)} Amps\n\n"

                            # Add pricing information
                            price_info = get_model_price(model["model_no"])
                            if price_info:
                                response += format_pricing(price_info)

                            response += "  Each Power Equipment includes:\n"
                            response += "  • Portable Shaft\n"
                            response += "  • Heavy-duty trailer\n"
                            response += "  • 10 ft cord with Anderson connector\n\n"

                    response += "Would you like to know more about any specific model or discuss financing options?"

                    # Reset state
                    state.flow = "general"
                    state.step = 0

                    return response
                except ValueError:
                    return "Please enter a valid number for horsepower"

        return None

    def handle_power_calculation(self, query: str, state: ConversationState) -> str:
        """Handle power calculation requests"""
        state.flow = "power_calculation"
        state.step = 1
        state.data = {}

        return (
            "Let me help you find the right Power Equipment!\n"
            "Which series are you interested in?\n"
            "• EU Series (7-31 KW)\n"
            "• GP Series (30-65 KW)\n"
            "• RY Series (30-100 KW)"
        )

    def handle_model_info(self, query: str, state: ConversationState) -> str:
        """Handle model information requests"""
        # Check for specific model
        model_match = re.search(r"(eu|gp|ry)\s*(\d+)", query, re.I)
        if model_match:
            series = model_match.group(1).upper()
            number = model_match.group(2)
            model = f"{series}{number}"

            # Load specifications
            specs = load_series_specifications(series)
            if not specs:
                return f"Specifications not available for {model}"

            # Find model specs
            model_specs = next(
                (m for m in specs["models"] if m["model_no"].replace(" ", "") == model),
                None,
            )
            if not model_specs:
                return f"Model {model} not found"

            return format_model_details(model_specs)

        # Check for series
        if "eu" in query.lower():
            specs = load_series_specifications("EU")
        elif "gp" in query.lower():
            specs = load_series_specifications("GP")
        elif "ry" in query.lower():
            specs = load_series_specifications("RY")
        else:
            return (
                "Please specify which series or model you're interested in:\n"
                "• EU Series (7-31 KW)\n"
                "• GP Series (30-65 KW)\n"
                "• RY Series (30-100 KW)"
            )

        return format_specifications(specs)

    def handle_pricing(self, query: str, state: ConversationState) -> str:
        """Handle pricing requests"""
        # Extract model number from query
        model_match = re.search(r"(eu|gp|ry)\s*(\d+)(?:-\d+)?", query, re.I)
        if not model_match:
            return (
                "Please specify which model you're interested in (e.g., EU7, GP30, RY45).\n"
                "All Power Equipments include:\n"
                "• Portable Shaft\n"
                "• Heavy-duty trailer\n"
                "• 10 ft cord with Anderson connector\n"
                "• 8% discount available for 8-week delivery"
            )

        series = model_match.group(1).upper()
        number = model_match.group(2)
        model = f"{series}{number}"
        if model.startswith("RY"):
            model = f"RY {number}"  # Add space for RY models

        price_info = get_model_price(model)
        if not price_info:
            return f"Pricing not available for {model}"

        response = [f"Pricing for {model}:"]

        # Add USD pricing if available
        if price_info["usd"] is not None:
            usd_regular = price_info["usd"]
            usd_discounted = usd_regular * (
                1 - price_info["discount"]["percentage"] / 100
            )
            response.append(f"\nUSD Price:")
            response.append(f"• Regular: ${usd_regular:,}")
            response.append(
                f"• With {price_info['discount']['percentage']}% discount ({price_info['discount']['condition']}): ${usd_discounted:,.2f}"
            )

        # Add CAD pricing if available
        if price_info["cad"] is not None:
            cad_regular = price_info["cad"]
            cad_discounted = cad_regular * (
                1 - price_info["discount"]["percentage"] / 100
            )
            response.append(f"\nCAD Price:")
            response.append(f"• Regular: ${cad_regular:,}")
            response.append(
                f"• With {price_info['discount']['percentage']}% discount ({price_info['discount']['condition']}): ${cad_discounted:,.2f}"
            )

        # Add included items at the end
        if price_info.get("includes"):
            response.append("\nPrice includes:")
            for item in price_info["includes"]:
                response.append(f"• {item}")

        return "\n".join(response)

    def handle_features(self, query: str, state: ConversationState) -> str:
        """Handle feature requests"""
        # Check for series
        if "eu" in query.lower():
            features = load_series_features("EU")
        elif "gp" in query.lower():
            features = load_series_features("GP")
        elif "ry" in query.lower():
            features = load_series_features("RY")
        else:
            return (
                "Which series would you like to know about?\n"
                "• EU Series (7-31 KW)\n"
                "• GP Series (30-65 KW)\n"
                "• RY Series (30-100 KW)"
            )

        return format_features(features)

    def handle_greeting(self) -> str:
        """Handle greetings"""
        return (
            "Welcome to  Power Equipment Assistant!\n"
            "I can help you with:\n"
            "• Calculate power requirements\n"
            "• Show Power Equipment specifications\n"
            "• Provide pricing information\n"
            "• Explain Power Equipment features\n"
            "What would you like to know?"
        )

    def handle_farewell(self, session_id: str) -> str:
        """Handle farewells"""
        if session_id in self.states:
            del self.states[session_id]
        return "Thank you for using  Power Equipment Assistant. Have a great day!"

    def handle_unknown_query(self) -> str:
        """Handle unknown queries"""
        return (
            "I can help you with:\n"
            "• Calculate power requirements\n"
            "• Show Power Equipment specifications\n"
            "• Provide pricing information\n"
            "• Explain Power Equipment features\n"
            "Please let me know what you'd like to know about."
        )


conversation_handler = ConversationHandler()

logging.basicConfig(level=logging.INFO)

app = Flask(__name__)
CORS(app)


class EquipmentPowerGuide:
    """Guide for common equipment power requirements"""

    EQUIPMENT_POWER = {
        "lawn mower": {"base_kw": 2.5, "description": "typical residential lawn mower"},
        "riding mower": {"base_kw": 4.0, "description": "riding lawn mower"},
        "circular saw": {"base_kw": 1.8, "description": "typical circular saw"},
        "table saw": {"base_kw": 2.0, "description": "standard table saw"},
        "drill": {"base_kw": 0.8, "description": "power drill"},
        "air compressor": {"base_kw": 2.2, "description": "standard air compressor"},
        "refrigerator": {"base_kw": 0.7, "description": "standard refrigerator"},
        "ac": {"base_kw": 3.5, "description": "air conditioning unit"},
        "heater": {"base_kw": 2.0, "description": "space heater"},
        "pump": {"base_kw": 1.5, "description": "water pump"},
    }

    @classmethod
    def get_equipment_power(cls, query: str) -> Tuple[float, str]:
        """Get estimated power requirement for equipment"""
        query = query.lower()
        for equipment, info in cls.EQUIPMENT_POWER.items():
            if equipment in query:
                return info["base_kw"], info["description"]
        return 0, ""


# Global variables
total_watts = None  # Track watts between power calculation steps


def get_model_price(model: str) -> dict:
    """Get the price information for a PC model"""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        json_path = os.path.join(current_dir, "json", "PC-Pricing.json")

        if os.path.exists(json_path):
            with open(json_path, "r") as f:
                pricing_data = json.load(f)

                # Initialize price info
                price_info = {
                    "thb": None,  # Thai Baht
                    "aur": None,  # Fictional AUR currency
                    "discount": {"percentage": 8, "condition": "Allow 8-week delivery"},
                    "includes": pricing_data.get("includes", []),
                }

                # Search through pricing data
                for model_data in pricing_data["models"]:
                    # Check THB prices
                    thb_models = model_data.get("Pricing", {}).get("THB", [])
                    for pc in thb_models:
                        if pc["PartNumber"] == model:
                            price_info["thb"] = pc["OriginalPrice"]
                            break

                    # Check AUR prices
                    aur_models = model_data.get("Pricing", {}).get("AUR", [])
                    for pc in aur_models:
                        if pc["PartNumber"] == model:
                            price_info["aur"] = pc["OriginalPrice"]
                            break

                return price_info

    except Exception as e:
        print(f"Error loading pricing data: {str(e)}")

    return None


def format_pricing(price_info: dict) -> str:
    """Format pricing information into a readable string"""
    if not price_info:
        return "Pricing information not available"

    response = []

    # Add price information
    response.append("Price includes:")
    for item in price_info["includes"]:
        response.append(f"• {item}")

    # Add THB pricing if available
    if price_info["thb"] is not None:
        thb_regular = price_info["thb"]
        thb_discounted = thb_regular * (1 - price_info["discount"]["percentage"] / 100)
        response.append(f"\nTHB Price:")
        response.append(f"• Regular: ฿{thb_regular:,}")
        response.append(
            f"• With {price_info['discount']['percentage']}% discount ({price_info['discount']['condition']}): ฿{thb_discounted:,.2f}"
        )

    # Add AUR pricing if available
    if price_info["aur"] is not None:
        aur_regular = price_info["aur"]
        aur_discounted = aur_regular * (1 - price_info["discount"]["percentage"] / 100)
        response.append(f"\nAUR Price:")
        response.append(f"• Regular: {aur_regular:,} AUR")
        response.append(
            f"• With {price_info['discount']['percentage']}% discount ({price_info['discount']['condition']}): {aur_discounted:,.2f} AUR"
        )

    return "\n".join(response)


# Initialize qa_chain globally
qa_chain = None

kb_json_paths = [
    "D:\\ollama\\json\\Power Equipments-excel.json",
    "D:\\ollama\\json\\GP-series-key-features.json",
    "D:\\ollama\\json\\GP-Specification.json",
    "D:\\ollama\\json\\RY-series-key-features.json",
    "D:\\ollama\\json\\RY-Specification.json",
    "D:\\ollama\\json\\EU-series-key-features.json",
    "D:\\ollama\\json\\EU-Specification.json",
]
pdf_path = "D:\\ollama\\-Power Equipments-overview.pdf"

# Add feedback storage
FEEDBACK_FILE = "feedback_data.json"
CONVERSATION_LOG = "conversation_log.txt"


@dataclass
class PowerCalculation:
    """Class to track power calculation state"""

    series: str
    amps_120v: Optional[float] = None
    amps_240v: Optional[float] = None
    total_hp: Optional[float] = None
    house_load: Optional[float] = None
    shop_load: Optional[float] = None
    step: int = 1  # 1: 120V, 2: 240V, 3: HP


# Global dictionary to store power calculations by session
power_calculations: Dict[str, PowerCalculation] = {}
power_calc_lock = threading.Lock()


def get_or_create_power_calculation(
    session_id: str, series: Optional[str] = None
) -> PowerCalculation:
    """Get or create a power calculation for a session"""
    with power_calc_lock:
        if session_id not in power_calculations and series:
            power_calculations[session_id] = PowerCalculation(series=series)
        return power_calculations.get(session_id)


def clear_power_calculation(session_id: str):
    """Clear power calculation for a session"""
    with power_calc_lock:
        if session_id in power_calculations:
            del power_calculations[session_id]


def handle_power_calculator_flow(
    query: str, chat_history: list, session_id: str = "default"
):
    """Handle the power calculator conversation flow"""
    query = query.lower().strip()

    # Direct power calculator request
    if query in ["calculate power", "power calculator", "i want to calculate power"]:
        clear_power_calculation(session_id)
        return (
            "Let me help you find the perfect Power Equipment for your needs!\n\n"
            "We offer three series of Power Equipments:\n"
            "• EU Series: 7-31 KW (ideal for small to medium loads)\n"
            "• GP Series: 30-65 KW (perfect for medium to large loads)\n"
            "• RY Series: 30-100 KW (designed for heavy-duty continuous operation)\n\n"
            "Which series would you like to explore? Just type EU, GP, or RY:"
        )

    # Series selection
    if query in ["eu", "gp", "ry"]:
        series = query.upper()
        calc = PowerCalculation(series=series)
        power_calculations[session_id] = calc

        if series == "EU":
            return "Great choice! First, I'll need to know your total amperage at 120V for all appliances. What's your 120V amp requirement?"
        else:
            return f"Excellent! For the {series} series, let's start with your house power needs. What's your house load in KW? (A typical house uses around 5KW)"

    # Get existing calculation
    calc = power_calculations.get(session_id)
    if not calc:
        return None

    # Try to parse number from query
    try:
        # Handle watts to KW conversion
        if "w" in query.lower() and "kw" not in query.lower():
            watts = float("".join(c for c in query if c.isdigit() or c == "."))
            number = watts / 1000  # Convert to KW
        else:
            number = float("".join(c for c in query if c.isdigit() or c == "."))
    except ValueError:
        return None

    # For GP and RY series with step-by-step input
    if calc.series in ["GP", "RY"]:
        if calc.step == 1:  # House load
            calc.house_load = number
            calc.step = 2
            return "Thanks! Now, do you have any additional loads like a shop or other equipment? Enter the power requirement in KW (enter 0 if none):"
        elif calc.step == 2:  # Shop load
            calc.shop_load = number
            calc.step = 3
            return "Almost done! Do you have any motors that need to be powered? Enter the total horsepower (HP) of all motors (enter 0 if none):"
        elif calc.step == 3:  # Motor HP
            calc.total_hp = number

            # Calculate total power needed
            total_kw = (
                calc.house_load + calc.shop_load + (calc.total_hp * 0.746)
            )  # Convert HP to KW

            suitable_models = find_suitable_power_equipment(total_kw)
            if not suitable_models:
                return f"I apologize, but I couldn't find any Power Equipments that meet your power requirement of {total_kw:.1f} KW. Please contact our sales team for a custom solution."

            response = f"Based on your requirements, here's what you need:\n\n"
            response += f"• House Load: {calc.house_load:.1f} KW\n"
            response += f"• Additional Load: {calc.shop_load:.1f} KW\n"
            response += (
                f"• Motor Load ({calc.total_hp} HP): {calc.total_hp * 0.746:.1f} KW\n"
            )
            response += f"• Total Power Required: {total_kw:.1f} KW\n"
            response += f"• Recommended Capacity (with 20% safety margin): {total_kw * 1.2:.1f} KW\n\n"

            # Show models from selected series
            series_models = [
                m for m in suitable_models if m["model_no"].startswith(calc.series)
            ]
            if series_models:
                response += (
                    f"Here are the {calc.series} Series models I recommend for you:\n\n"
                )
                for model in series_models[:2]:
                    response += f"✦ {model['model_no']} Power Equipment:\n"
                    response += f"  • Continuous Power: {model['kw']} KW\n"
                    response += f"  • Surge Capacity: {model['surge']} KW (perfect for motor startup)\n"
                    response += f"  • Operating Speed: {model['rpm']} RPM\n"
                    response += f"  • Full Load Capacity: {model['amps']} Amps\n\n"

                    # Add pricing information
                    price_info = get_model_price(model["model_no"])
                    if price_info:
                        response += format_pricing(price_info)

                    response += "  Each Power Equipment includes:\n"
                    response += "  • Portable Shaft\n"
                    response += "  • Heavy-duty trailer\n"
                    response += "  • 10 ft cord with Anderson connector\n\n"

            # If no models in selected series, suggest alternatives
            if not series_models:
                other_models = [
                    m
                    for m in suitable_models
                    if not m["model_no"].startswith(calc.series)
                ]
                if other_models:
                    response += f"Your power requirement exceeds the {calc.series} series capacity. Here are some alternative recommendations:\n\n"
                    for model in other_models[:2]:
                        response += f"✦ {model['model_no']} Power Equipment:\n"
                        response += f"  • Continuous Power: {model['kw']} KW\n"
                        response += f"  • Surge Capacity: {model['surge']} KW (perfect for motor startup)\n"
                        response += f"  • Operating Speed: {model['rpm']} RPM\n"
                        response += f"  • Full Load Capacity: {model['amps']} Amps\n\n"

                        # Add pricing information
                        price_info = get_model_price(model["model_no"])
                        if price_info:
                            response += format_pricing(price_info)

                        response += "  Each Power Equipment includes:\n"
                        response += "  • Portable Shaft\n"
                        response += "  • Heavy-duty trailer\n"
                        response += "  • 10 ft cord with Anderson connector\n\n"

            response += "Would you like to know more about any specific model or discuss financing options?"

            clear_power_calculation(session_id)
            return response

    # Handle EU series calculation steps
    if calc.series == "EU":
        if calc.step == 1:  # 120V amps
            calc.amps_120v = number
            calc.step = 2
            return "Got it! Now, what's your total amperage requirement at 240V? (Enter 0 if you don't have any 240V appliances)"

        elif calc.step == 2:  # 240V amps
            calc.amps_240v = number
            calc.step = 3
            return "Last question: Do you have any motors that need to be powered? Enter the total horsepower (HP) of all motors (enter 0 if none):"

        elif calc.step == 3:  # HP
            calc.total_hp = number

            # Calculate total power needed
            power_120v = (calc.amps_120v * 120) / 1000  # Convert to KW
            power_240v = (calc.amps_240v * 240) / 1000  # Convert to KW
            power_hp = calc.total_hp * 0.746  # Convert HP to KW
            total_kw = power_120v + power_240v + power_hp

            suitable_models = find_suitable_power_equipment(total_kw)
            if not suitable_models:
                return f"I apologize, but I couldn't find any Power Equipments that meet your power requirement of {total_kw:.1f} KW. Please contact our sales team for a custom solution."

            response = f"Based on your requirements, here's what you need:\n\n"
            response += f"• 120V Load: {power_120v:.1f} KW\n"
            response += f"• 240V Load: {power_240v:.1f} KW\n"
            response += f"• Motor Load ({calc.total_hp} HP): {power_hp:.1f} KW\n"
            response += f"• Total Power Required: {total_kw:.1f} KW\n"
            response += f"• Recommended Capacity (with 20% safety margin): {total_kw * 1.2:.1f} KW\n\n"

            # First try EU series models
            eu_models = [m for m in suitable_models if m["model_no"].startswith("EU")]
            if eu_models:
                response += "Here are the EU Series models I recommend for you:\n\n"
                for model in eu_models[:2]:
                    response += f"✦ {model['model_no']} Power Equipment:\n"
                    response += f"  • Continuous Power: {model['kw']} KW\n"
                    response += f"  • Surge Capacity: {model['surge']} KW (perfect for motor startup)\n"
                    response += f"  • Operating Speed: {model['rpm']} RPM\n"
                    response += f"  • Full Load Capacity: {model['amps']} Amps\n\n"

                    # Add pricing information
                    price_info = get_model_price(model["model_no"])
                    if price_info:
                        response += format_pricing(price_info)

                    response += "  Each Power Equipment includes:\n"
                    response += "  • Portable Shaft\n"
                    response += "  • Heavy-duty trailer\n"
                    response += "  • 10 ft cord with Anderson connector\n\n"

            # If power requirement exceeds EU series capacity, suggest alternatives
            if not eu_models:
                response += f"Your power requirement of {total_kw:.1f} KW exceeds the EU series capacity (7-31 KW).\n"
                response += "Here are some alternative recommendations that will better meet your needs:\n\n"
                for model in suitable_models[:2]:
                    response += f"✦ {model['model_no']} Power Equipment:\n"
                    response += f"  • Continuous Power: {model['kw']} KW\n"
                    response += f"  • Surge Capacity: {model['surge']} KW (perfect for motor startup)\n"
                    response += f"  • Operating Speed: {model['rpm']} RPM\n"
                    response += f"  • Full Load Capacity: {model['amps']} Amps\n\n"

                    # Add pricing information
                    price_info = get_model_price(model["model_no"])
                    if price_info:
                        response += format_pricing(price_info)

                    response += "  Each Power Equipment includes:\n"
                    response += "  • Portable Shaft\n"
                    response += "  • Heavy-duty trailer\n"
                    response += "  • 10 ft cord with Anderson connector\n\n"

            response += "Would you like to know more about any specific model or discuss financing options?"

            clear_power_calculation(session_id)
            return response

    return None


def log_conversation(user_query, assistant_response, success_rate=1.0):
    """Log conversation to both JSON and EUT files with timestamp and success rate"""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Prepare log entry
    log_entry = {
        "timestamp": timestamp,
        "user_query": user_query,
        "assistant_response": assistant_response,
        "success_rate": success_rate,
    }

    # Log to JSON file
    json_file = Path("conversations.json")
    try:
        # Initialize logs list
        if json_file.exists():
            try:
                with open(json_file, "r", encoding="utf-8") as f:
                    logs = json.load(f)
                if not isinstance(logs, list):
                    logs = []
            except json.JSONDecodeError:
                logs = []
        else:
            logs = []

        # Append new entry
        logs.append(log_entry)

        # Write back to file
        with open(json_file, "w", encoding="utf-8") as f:
            json.dump(logs, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"Error logging to JSON: {str(e)}")
        # Create a backup of the corrupted file if it exists
        if json_file.exists():
            backup_file = Path("conversations_backup.json")
            try:
                json_file.rename(backup_file)
                print(f"Created backup of corrupted JSON file: {backup_file}")
            except Exception as backup_error:
                print(f"Error creating backup: {str(backup_error)}")

    # Log to EUT file
    eut_file = Path("conversations.txt")
    try:
        with open(eut_file, "a", encoding="utf-8") as f:
            f.write(f"\n{'='*80}\n")
            f.write(f"Timestamp: {timestamp}\n")
            f.write(f"Success Rate: {success_rate*100:.1f}%\n\n")
            f.write("User: " + user_query + "\n\n")
            f.write("Assistant: " + assistant_response + "\n")
    except Exception as e:
        print(f"Error logging to EUT: {str(e)}")


def calculate_success_rate(response):
    """Calculate success rate based on response content"""
    success_rate = 1.0

    if "I apologize" in response or "I encountered an error" in response:
        success_rate = 0.0
    elif (
        "I can help you with" in response and "What would you like to know?" in response
    ):
        success_rate = 0.5
    elif "please provide" in response.lower() or "please specify" in response.lower():
        success_rate = 0.7

    return success_rate


def load_conversation_logs():
    try:
        json_file = Path("conversations.json")
        if not json_file.exists():
            return []

        try:
            with open(json_file, "r", encoding="utf-8") as f:
                logs = json.load(f)
                if not isinstance(logs, list):
                    return []
                return logs
        except json.JSONDecodeError:
            print("Error reading conversation logs, starting fresh")
            return []
    except Exception as e:
        print(f"Error loading conversation logs: {str(e)}")
        return []


def categorize_query(query: str) -> str:
    """Categorize the query type based on its content"""
    query = query.lower()
    if any(
        x in query
        for x in ["calculate power", "power calculator", "watts", "kw", "amps"]
    ):
        return "power_calculation"
    elif any(x in query for x in ["price", "cost", "how much", "$"]):
        return "pricing"
    elif any(x in query for x in ["eu series", "gp series", "ry series"]):
        return "series_info"
    elif any(x in query for x in ["specification", "specs", "features"]):
        return "specifications"
    return "other"


def load_feedback_data():
    # First load existing feedback data
    if os.path.exists(FEEDBACK_FILE):
        with open(FEEDBACK_FILE, "r", encoding="utf-8") as f:
            feedback_data = json.load(f)
    else:
        feedback_data = {"interactions": [], "successful_patterns": {}}

    # Then integrate conversation logs
    conversation_logs = load_conversation_logs()
    for conv in conversation_logs:
        # Add to interactions if not already present
        if not any(i["query"] == conv["query"] for i in feedback_data["interactions"]):
            interaction = {
                "timestamp": conv["timestamp"],
                "query": conv["query"],
                "response": conv["response"],
                "success": True,  # Assume logged conversations were successful
            }
            feedback_data["interactions"].append(interaction)

            # Update successful patterns
            query_type = categorize_query(conv["query"])
            if query_type not in feedback_data["successful_patterns"]:
                feedback_data["successful_patterns"][query_type] = []
            feedback_data["successful_patterns"][query_type].append(
                {"query": conv["query"], "response": conv["response"]}
            )

    return feedback_data


def save_feedback_data(data):
    with open(FEEDBACK_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def update_training_data(query, response, success=True):
    feedback_data = load_feedback_data()  # This now includes conversation logs

    # Store the interaction
    interaction = {
        "timestamp": datetime.datetime.now().isoformat(),
        "query": query,
        "response": response,
        "success": success,
    }

    # Only add if it's not already present
    if not any(i["query"] == query for i in feedback_data["interactions"]):
        feedback_data["interactions"].append(interaction)

    # Update successful patterns
    if success:
        query_type = categorize_query(query)
        if query_type not in feedback_data["successful_patterns"]:
            feedback_data["successful_patterns"][query_type] = []

        # Only add if it's a new pattern
        if not any(
            p["query"] == query
            for p in feedback_data["successful_patterns"][query_type]
        ):
            feedback_data["successful_patterns"][query_type].append(
                {"query": query, "response": response}
            )

    save_feedback_data(feedback_data)


def enhance_prompt_with_examples(query_type):
    feedback_data = load_feedback_data()
    successful_patterns = feedback_data.get("successful_patterns", {})
    examples = successful_patterns.get(query_type, [])

    if not examples:
        return ""

    # Use the most recent successful example
    best_example = examples[-1]
    return (
        f"\nExample Q: {best_example['query']}\nExample A: {best_example['response']}\n"
    )


def load_knowledge_base(kb_paths, pdf_path):
    kb_text = ""

    if isinstance(kb_paths, list):
        for kb_path in kb_paths:
            if kb_path.endswith(".json"):
                try:
                    with open(kb_path, "r", encoding="utf-8") as file:
                        kb_data = json.load(file)
                except (IOError, json.JSONDecodeError) as e:
                    print(f"Error loading {kb_path}: {e}")
                    continue

                # Handle pricing data
                if "Power Equipments" in kb_data:
                    kb_text += "\nPower Equipment Pricing Information:\n"

                    # USD Pricing
                    kb_text += "\nPower Equipment Models - USD Prices:\n"
                    for model in kb_data["Power Equipments"]["USD"]:
                        model_text = (
                            f"Model {model['PartNumber']} pricing (USD):\n"
                            f"Regular price: ${model['OriginalPrice']}\n"
                            f"Discounted price: ${model['DiscountPrice']}\n"
                            f"Discount details: {model['Conditions']['Discount']['Value']}% off when you {model['Conditions']['Discount']['Requirement']}\n"
                        )
                        kb_text += model_text

                        # CAD Pricing
                        kb_text += "\nPower Equipment Models - CAD Prices:\n"
                        for model in kb_data["Power Equipments"]["CAD"]:
                            model_text = (
                                f"Model {model['PartNumber']} pricing (CAD):\n"
                                f"Regular price: CAD ${model['OriginalPrice']}\n"
                                f"Discounted price: CAD ${model['DiscountPrice']}\n"
                                f"Discount details: {model['Conditions']['Discount']['Value']}% off when you {model['Conditions']['Discount']['Requirement']}\n"
                            )
                            kb_text += model_text

                        # Add mounting options information
                        kb_text += "\nMounting Options:\n"

                        # Trailers
                        kb_text += "\nTrailers (USD):\n"
                        for trailer in kb_data["Trailers"]["USD"]:
                            kb_text += (
                                f"- {trailer['Description']}: ${trailer['Price']}\n"
                            )

                        # Portable Shafts
                        kb_text += "\nPortable Shafts (USD):\n"
                        for shaft in kb_data["PortableShafts"]["USD"]:
                            kb_text += f"- {shaft['Description']}: ${shaft['Price']}\n"
                        # Electric Cables
                        kb_text += "\nElectric Cables (USD per foot):\n"
                        for cable in kb_data["ElectricCables"]["USD"]:
                            kb_text += (
                                f"- {cable['Description']}: ${cable['PricePerFoot']}\n"
                            )

                elif "models" in kb_data:
                    series_name = os.path.basename(kb_path).split("-")[0]
                    kb_text += f"\nPower Equipment Series: {series_name}\n"
                    kb_text += f"Available Models in {series_name} Series:\n"

                    for model in kb_data["models"]:
                        kb_text += f"\nModel {model['model_no']} Specifications:\n"
                        kb_text += (
                            f"- Power Output: {model.get('kw', 'N/A')} KW\n"
                            f"- Surge Capacity: {model.get('momentary_surge_kw', 'N/A')} KW\n"
                            f"- Operating RPM: {model.get('internal_rpm', model.get('rpm', 'Not specified'))}\n"
                            f"- Shipping Weight: {model.get('shipping_weight_lbs', 'N/A')} lbs\n"
                        )

                        models = kb_data["models"]
                        min_kw = min(models, key=lambda x: x["kw"])
                        max_kw = max(models, key=lambda x: x["kw"])
                        rpm_value = models[0].get(
                            "internal_rpm", models[0].get("rpm", "Not specified")
                        )

                        kb_text += f"\nSeries Summary for {series_name}:\n"
                        kb_text += (
                            f"- Power Range: {min_kw['kw']} KW to {max_kw['kw']} KW\n"
                        )
                        kb_text += f"- Surge Range: {min_kw['momentary_surge_kw']} KW to {max_kw['momentary_surge_kw']} KW\n"
                        kb_text += f"- All {series_name} models ({', '.join(m['model_no'] for m in models)}) operate at {rpm_value} RPM\n"
                        kb_text += f"- Highest power model: {max_kw['model_no']} at {max_kw['kw']} KW with {max_kw['momentary_surge_kw']} KW surge\n\n"

                elif "key_features" in kb_data:
                    series_name = os.path.basename(kb_path).split("-")[0]
                    kb_text += f"\nKey Features for {series_name} Series:\n"
                    for feature in kb_data["key_features"]:
                        name = feature.get("name", "Unknown Feature")
                        description = feature.get("description", "No description")
                        kb_text += f"Feature: {name}\nDescription: {description}\n\n"

    if isinstance(pdf_path, str) and pdf_path.endswith(".pdf"):
        try:
            with open(pdf_path, "rb") as pdf_file:
                reader = PyPDF2.PdfReader(pdf_file)
                for page in reader.pages:
                    kb_text += page.extract_text() + "\n"
        except Exception as e:
            raise ValueError(f"Error loading knowledge base from PDF: {str(e)}")

    return kb_text


def create_vector_store(kb_text):
    from langchain.text_splitter import RecursiveCharacterTextSplitter

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    chunks = text_splitter.split_text(kb_text)

    print(f"Number of chunks created: {len(chunks)}")

    if not chunks:
        raise ValueError("No valid chunks created from knowledge base")

    embedding_model = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    vector_store = FAISS.from_texts(chunks, embedding_model)
    print("Vector store created successfully")
    return vector_store


def setup_retrieval_qa(vector_store):
    os.environ["HUGGINGFACEHUB_API_TOKEN"]
    huggingface_api_token = os.environ.get("HUGGINGFACEHUB_API_TOKEN")
    if not huggingface_api_token:
        raise ValueError("HUGGINGFACEHUB_API_TOKEN environment variable is not set")

    llm = HuggingFaceEndpoint(
        repo_id="Qwen/Qwen2.5-Coder-32B-Instruct",
        task="text-generation",
        temperature=0.2,
        top_p=0.95,
    )

    template = """
    You are a knowledgeable  Power Equipment Assistant. Use ONLY the provided context to respond to the current question. Present information in clear, natural sentences. If no information is available, say so.
    
    Guidelines:
    - Never assume any information on your own and provide answers based on the context
    - Present prices in a conversational way
    - Include all pricing details in complete sentences
    - Always mention both USD and CAD prices when available
    - Include the discount information naturally in the flow
    - Mention that the price includes Portable Shaft, Trailer, and 10 ft cord with Anderson connector
    - Never use bullet points or numbered lists
    - Never make up or estimate prices
    - If you're not 100% certain about a price, say the information is not available
    - Format prices exactly as they appear in the data
    - DO NOT generate any questions or answers on your own
    - ONLY respond to the user's input and do not create a conversation
    - DO NOT assume or generate any input as if it were from a human
    
    Context: {context}
    Current conversation: {chat_history}
    Human: {question}

    Assistant: """

    prompt = PromptTemplate(
        input_variables=["context", "chat_history", "question"],
        template=template,
    )

    return ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=vector_store.as_retriever(search_kwargs={"k": 3}),
        combine_docs_chain_kwargs={"prompt": prompt},
        return_source_documents=True,
    )


def type_out_response(response):
    """Simulate typing effect for the response."""
    for char in response:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.005)
    print()


def extract_model_number(query):
    # List of model patterns to look for
    model_patterns = [
        (r"EU\s*(\d+)", "EU{}"),  # EU series
        (r"RY\s*(\d+)(?:-\d+)?", "RY{}"),  # RY series (with optional suffix)
        (r"GP\s*(\d+)", "GP{}"),  # GP series
    ]

    query = query.upper()  # Convert to uppercase for consistency
    for pattern, format_str in model_patterns:
        match = re.search(pattern, query)
        if match:
            model_number = format_str.format(match.group(1))
            # Remove any spaces in the model number
            return model_number.replace(" ", "")
    return None


def parse_equipment_list(input_str):
    """Parse equipment list from user input with advanced recognition"""
    print(f"Parsing equipment list for input: {input_str}")  # Debug print
    equipment_list = []

    # Predefined equipment power dictionary with more comprehensive details
    EQUIPMENT_POWER = {
        "ac": {
            "watts": 3500,
            "description": "Standard Air Conditioner",
            "typical_size": "5000-15000 BTU",
            "voltage": "240V",
            "hp": 3,
        },
        "air conditioner": {
            "watts": 3500,
            "description": "Standard Air Conditioner",
            "typical_size": "5000-15000 BTU",
            "voltage": "240V",
            "hp": 3,
        },
        "lawn mower": {
            "watts": 1500,
            "description": "Typical Lawn Mower",
            "types": ["Electric", "Battery", "Gas-powered"],
            "hp": 3.5,
        },
        "riding mower": {
            "watts": 2500,
            "description": "Riding Lawn Mower",
            "typical_engine_size": "14-24 HP",
            "hp": 18,
        },
        "refrigerator": {
            "watts": 700,
            "description": "Standard Refrigerator",
            "voltage": "120V",
        },
        "fridge": {
            "watts": 700,
            "description": "Standard Refrigerator",
            "voltage": "120V",
        },
        "welder": {
            "watts": 5000,
            "description": "Typical Welding Machine",
            "voltage": "240V",
            "hp": 2,
        },
        "compressor": {
            "watts": 2200,
            "description": "Standard Air Compressor",
            "hp": 5,
        },
        "air compressor": {
            "watts": 2200,
            "description": "Standard Air Compressor",
            "hp": 5,
        },
        "drill": {"watts": 800, "description": "Power Drill", "voltage": "120V"},
        "circular saw": {
            "watts": 1800,
            "description": "Circular Saw",
            "voltage": "120V",
        },
        "table saw": {
            "watts": 2000,
            "description": "Table Saw",
            "voltage": "240V",
            "hp": 2,
        },
        "pump": {"watts": 1500, "description": "Water Pump", "hp": 1},
        "heater": {"watts": 2000, "description": "Space Heater", "voltage": "120V"},
    }

    # Normalize input
    input_str = input_str.lower()

    # First, try to match exact equipment names
    for equipment, details in EQUIPMENT_POWER.items():
        if equipment in input_str:
            print(f"Found exact match for: {equipment}")  # Debug print
            equipment_list.append(
                {
                    "name": equipment,
                    "watts": details.get("watts", 0),
                    "description": details.get("description", ""),
                    "hp": details.get("hp", 0),
                    "voltage": details.get("voltage", ""),
                }
            )

    # If no matches found, try more flexible parsing
    if not equipment_list:
        # Split input into words
        words = input_str.split()

        for word in words:
            for equipment, details in EQUIPMENT_POWER.items():
                if word in equipment:
                    print(f"Found partial match for: {equipment}")  # Debug print
                    equipment_list.append(
                        {
                            "name": equipment,
                            "watts": details.get("watts", 0),
                            "description": details.get("description", ""),
                            "hp": details.get("hp", 0),
                            "voltage": details.get("voltage", ""),
                        }
                    )

    # If still no matches, return a default response
    if not equipment_list:
        print("No equipment matches found")  # Debug print
        return None

    print(f"Final equipment list: {equipment_list}")  # Debug print
    return equipment_list


def calculate_power_needs(equipment_list):
    """Calculate power needs for equipment with Power Equipment recommendations"""
    if not equipment_list:
        return "I couldn't identify any specific equipment. Could you list your equipment more clearly?"

    # Calculate total power
    total_watts = sum(item.get("watts", 0) for item in equipment_list)
    total_hp = sum(item.get("hp", 0) for item in equipment_list)

    total_kw = total_watts / 1000
    motor_kw = total_hp * 0.746  # Convert HP to KW

    recommended_kw = (total_kw + motor_kw) * 1.2  # Add 20% safety margin

    # Prepare response
    response = "Power Requirements Analysis:\n\n"
    response += "Equipment Breakdown:\n"
    for item in equipment_list:
        details = []
        if item.get("watts"):
            details.append(f"{item['watts']} watts")
        if item.get("hp"):
            details.append(f"{item['hp']} HP")
        if item.get("voltage"):
            details.append(f"{item['voltage']}")

        response += (
            f"• {item['name'].title()} ({item['description']}): {', '.join(details)}\n"
        )

    response += f"\nTotal Electrical Load: {total_kw:.1f} KW\n"
    response += f"Total Motor Load: {motor_kw:.1f} KW\n"
    response += f"Recommended Power Equipment Capacity (with 20% margin): {recommended_kw:.1f} KW\n\n"

    # Find suitable Power Equipments
    suitable_models = find_suitable_power_equipment(recommended_kw)

    if not suitable_models:
        return "No suitable Power Equipments found for your power requirements."

    response += "Recommended Power Equipment Models:\n"
    for model in suitable_models:
        response += f"\n{model['model_no']} Power Equipment:\n"
        response += f"• Continuous Power: {model['kw']} KW\n"
        response += (
            f"• Surge Capacity: {model['surge_kw']} KW (perfect for motor startup)\n"
        )
        response += f"• Operating Speed: {model['rpm']} RPM\n"
        response += f"• Full Load Capacity: {model['amps']} Amps\n"

        # Add pricing information
        price_info = get_model_price(model["model_no"])
        if price_info:
            response += "\nPricing:\n"
            if price_info["usd"] is not None:
                response += f"• USD Price: ${price_info['usd']:,}\n"
            if price_info["cad"] is not None:
                response += f"• CAD Price: ${price_info['cad']:,}\n"

        response += "  Each Power Equipment includes:\n"
        response += "  • Portable Shaft\n"
        response += "  • Heavy-duty trailer\n"
        response += "  • 10 ft cord with Anderson connector\n\n"

    response += "Note: Always consult with a professional to ensure proper Power Equipment sizing for your specific needs."

    return response


def find_suitable_power_equipment(required_kw: float) -> list:
    """Find suitable Power Equipments based on power requirement"""
    eu_specs, gp_specs, ry_specs = calculate_power_needs()

    # Combine all models
    all_power_equipment = []
    if eu_specs and "models" in eu_specs:
        all_power_equipment.extend(eu_specs["models"])
    if gp_specs and "models" in gp_specs:
        all_power_equipment.extend(gp_specs["models"])
    if ry_specs and "models" in ry_specs:
        all_power_equipment.extend(ry_specs["models"])

    # Find suitable Power Equipments
    suitable = []
    for g in all_power_equipment:
        # Use 'kw' instead of 'kw'
        power = g.get("kw", g.get("power", g.get("output", 0)))

        # Try multiple field names for surge power
        surge_power = g.get(
            "surge_kw",
            g.get(
                "momentary_surge_kw",
                g.get("surge", g.get("peak_power", power * 2)),
            ),
        )
        if power >= required_kw:
            suitable.append(
                {
                    "model_no": g.get("model_no", g.get("model", "Unknown")),
                    "kw": power,
                    "surge_kw": surge_power,
                    "voltage": g.get("voltage", "240"),
                    "amps": g.get("amps", 0),
                    "rpm": g.get("rpm", g.get("internal_rpm", 1800)),
                }
            )

    if not suitable and all_power_equipment:
        max_generator = max(
            all_power_equipment,
            key=lambda x: x.get("kw", x.get("power", x.get("output", 0))),
        )
        power = max_generator.get(
            "kw", max_generator.get("power", max_generator.get("output", 0))
        )
        surge_power = max_generator.get(
            "surge_kw",
            max_generator.get(
                "momentary_surge_kw",
                max_generator.get("surge", max_generator.get("peak_power", power * 2)),
            ),
        )
        suitable.append(
            {
                "model_no": max_generator.get(
                    "model_no", max_generator.get("model", "Unknown")
                ),
                "kw": power,
                "surge_kw": surge_power,
                "voltage": max_generator.get("voltage", "240"),
                "amps": max_generator.get("amps", 0),
                "rpm": max_generator.get(
                    "rpm", max_generator.get("internal_rpm", 1800)
                ),
            }
        )

        # Find the next highest capacity Power Equipment
        remaining = [g for g in all_power_equipment if g != max_generator]
        if remaining:
            next_highest = max(
                remaining,
                key=lambda x: x.get("kw", x.get("power", x.get("output", 0))),
            )
            next_power = next_highest.get(
                "kw", next_highest.get("power", next_highest.get("output", 0))
            )
            next_surge_power = next_highest.get(
                "surge_kw",
                next_highest.get(
                    "momentary_surge_kw",
                    next_highest.get(
                        "surge",
                        next_highest.get("peak_power", next_power * 2),
                    ),
                ),
            )

            suitable.append(
                {
                    "model_no": next_highest.get(
                        "model_no", next_highest.get("model", "Unknown")
                    ),
                    "kw": next_power,
                    "surge_kw": next_surge_power,
                    "voltage": next_highest.get("voltage", "240"),
                    "amps": next_highest.get("amps", 0),
                    "rpm": next_highest.get(
                        "rpm", next_highest.get("internal_rpm", 1800)
                    ),
                }
            )
    # Sort by power capacity and return up to 2 models
    return sorted(suitable, key=lambda x: x["kw"])[:2]


def detect_equipment_intent(query: str) -> Optional[List[Dict]]:
    """
    Detect if the query contains equipment that requires power calculation

    Args:
        query (str): User's input query

    Returns:
        Optional list of detected equipment
    """
    # Predefined equipment power dictionary
    EQUIPMENT_POWER = {
        "ac": {
            "watts": 3500,
            "description": "Standard Air Conditioner",
            "typical_size": "5000-15000 BTU",
            "voltage": "240V",
            "hp": 3,
        },
        "air conditioner": {
            "watts": 3500,
            "description": "Standard Air Conditioner",
            "typical_size": "5000-15000 BTU",
            "voltage": "240V",
            "hp": 3,
        },
        "lawn mower": {
            "watts": 1500,
            "description": "Typical Lawn Mower",
            "types": ["Electric", "Battery", "Gas-powered"],
            "hp": 3.5,
        },
        "riding mower": {
            "watts": 2500,
            "description": "Riding Lawn Mower",
            "typical_engine_size": "14-24 HP",
            "hp": 18,
        },
        # Add more equipment as needed
    }

    # Normalize query
    query_lower = query.lower()

    # Detect equipment
    detected_equipment = []
    for equipment, details in EQUIPMENT_POWER.items():
        if equipment in query_lower:
            detected_equipment.append(
                {
                    "name": equipment,
                    "watts": details.get("watts", 0),
                    "description": details.get("description", ""),
                    "hp": details.get("hp", 0),
                    "voltage": details.get("voltage", ""),
                }
            )

    return detected_equipment if detected_equipment else None


def handle_equipment_query(
    query: str, chat_history: list = None, session_id: str = "default"
) -> str:
    """
    Handle queries with equipment power requirements

    Args:
        query (str): User's input query
        chat_history (list, optional): Conversation history
        session_id (str, optional): Session identifier

    Returns:
        str: Detailed equipment power recommendation
    """
    try:
        # Import here to avoid circular import
        from backend.distinct import EquipmentPowerAssistant

        # Create equipment power assistant
        assistant = EquipmentPowerAssistant()

        # Process equipment query
        power_result = assistant.process_equipment_query(query)

        # Generate detailed recommendation
        detailed_recommendation = assistant.generate_detailed_recommendation(
            query, power_result
        )

        return detailed_recommendation

    except Exception as e:
        logging.error(f"Equipment query processing error: {str(e)}")
        return "I apologize, but I encountered an error processing your equipment power query. Could you please rephrase or provide more details?"


def ask_question(qa_chain, user_query, chat_history):
    # List of equipment keywords to trigger power calculation
    equipment_keywords = [
        "ac",
        "air conditioner",
        "lawn mower",
        "riding mower",
        "Power Equipment",
        "power",
        "watts",
        "hp",
        "horsepower",
    ]

    # Check if query contains any equipment keywords
    if any(keyword in user_query.lower() for keyword in equipment_keywords):
        try:
            # Import here to avoid circular import
            from backend.distinct import EquipmentPowerAssistant

            # Create equipment power assistant
            assistant = EquipmentPowerAssistant()

            # Process equipment query
            power_result = assistant.process_equipment_query(user_query)

            # Generate detailed recommendation
            detailed_recommendation = assistant.generate_detailed_recommendation(
                user_query, power_result
            )

            return detailed_recommendation
        except Exception as e:
            logging.error(f"Equipment query processing error: {str(e)}")
            return "I can help you calculate power requirements for your equipment. Could you specify the equipment and its details?"

    # Fallback to QA chain if no equipment detected
    try:
        result = qa_chain.invoke(
            {"question": user_query, "chat_history": chat_history}, timeout=300
        )
        if result and "answer" in result:
            return result["answer"].strip()
    except Exception as qa_error:
        logging.error(f"QA Chain error: {str(qa_error)}")

    return "I can help you calculate power requirements. Please specify your equipment or power needs."


class ConversationFlows:
    """Different types of conversation flows"""

    GENERAL = "general"
    POWER_CALC = "power_calc"
    MODEL_INFO = "model_info"
    MODEL_FEATURES = "model_features"
    MODEL_PRICING = "model_pricing"
    RECOMMENDATION = "recommendation"


@dataclass
class ConversationState:
    """Class to track conversation state"""

    flow: str = ConversationFlows.GENERAL
    step: int = 0
    data: dict = field(default_factory=dict)


class IntentMatcher:
    """Match user queries to intents"""

    def __init__(self):
        self.intents = {
            "show_models": [
                "show models",
                "specifications",
                "specs",
                "details",
                "tell me about models",
                "what models",
                "which models",
                "model specifications",
                "technical details",
                "show me the models",
                "Power Equipment models",
                "available models",
            ],
            "show_features": [
                "features",
                "what features",
                "key features",
                "capabilities",
                "what can they do",
                "tell me about features",
                "Power Equipment features",
                "what are the features",
                "show features",
                "feature list",
            ],
            "show_pricing": [
                "pricing",
                "price",
                "cost",
                "how much",
                "prices",
                "price list",
                "tell me about pricing",
                "what is the price",
                "show me prices",
                "price information",
                "costs",
            ],
            "calculate_power": [
                "calculate power",
                "power calculator",
                "find Power Equipment",
                "what size Power Equipment",
                "which Power Equipment do i need",
                "power requirements",
                "calculate requirements",
                "size calculator",
                "recommend Power Equipment",
                "what Power Equipment do i need",
                "help me choose",
                "select Power Equipment",
            ],
            "general_info": [
                "what Power Equipments",
                "which Power Equipments",
                "Power Equipment options",
                "available Power Equipments",
                "Power Equipment series",
                "types of Power Equipments",
                "what Power Equipments do you have",
                "tell me about Power Equipments",
                "show me Power Equipments",
                "Power Equipment information",
            ],
        }

    def match_intent(self, query: str) -> tuple[str, float]:
        """Match query to intent using fuzzy matching"""
        query = query.lower().strip()
        best_match = (None, 0)

        # First check for exact matches in intents
        for intent, patterns in self.intents.items():
            if query in patterns:
                return intent, 1.0

            # Check if query contains any pattern
            for pattern in patterns:
                if pattern in query:
                    return intent, 0.9

        # If no exact match, check for partial matches
        for intent, patterns in self.intents.items():
            for pattern in patterns:
                # Check word overlap
                query_words = set(query.split())
                pattern_words = set(pattern.split())
                common_words = query_words & pattern_words

                if common_words:
                    score = len(common_words) / max(
                        len(query_words), len(pattern_words)
                    )
                    if score > best_match[1]:
                        best_match = (intent, score)

        return best_match if best_match[1] > 0.3 else (None, 0)


def calculate_success_rate(response: str) -> float:
    """Calculate success rate based on response quality"""
    if not response:
        return 0.0

    # Check for error messages or apologies
    if any(
        phrase in response.lower()
        for phrase in ["error", "sorry", "apologize", "not available"]
    ):
        return 0.5

    # Check for specific content indicators
    has_numbers = bool(re.search(r"\d", response))
    has_model_info = any(series in response.upper() for series in ["EU", "GP", "RY"])
    has_units = any(unit in response.lower() for unit in ["kw", "watts", "hp", "amps"])
    has_features = (
        "features" in response.lower() or "specifications" in response.lower()
    )

    # Calculate score based on content quality
    score = 0.7  # Base score
    if has_numbers:
        score += 0.1
    if has_model_info:
        score += 0.1
    if has_units:
        score += 0.05
    if has_features:
        score += 0.05

    return min(score, 1.0)


def log_conversation(query: str, response: str, success_rate: float):
    """Log conversation details with timestamp"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] Query: {query} | Response: {response} | Success Rate: {success_rate:.2f}\n"

    try:
        with open("conversation_logs.txt", "a", encoding="utf-8") as f:
            f.write(log_entry)
    except Exception as e:
        print(f"Error writing to log file: {e}")


@app.route("/api/chat", methods=["POST"])
def chat_endpoint():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400

        user_query = data.get("query", "")
        chat_history = data.get("history", [])
        session_id = data.get("session_id", "default")

        if not user_query:
            return jsonify({"error": "No query provided"}), 400

        # Get response from conversation handler
        response_text = conversation_handler.handle_conversation(
            user_query, chat_history, session_id
        )

        # Calculate success rate
        success_rate = calculate_success_rate(response_text)

        # Log the conversation
        log_conversation(user_query, response_text, success_rate)

        # Update chat history
        chat_history.append({"content": user_query, "role": "user"})
        chat_history.append({"content": response_text, "role": "assistant"})

        return (
            jsonify(
                {
                    "response": response_text,
                    "history": chat_history,
                    "session_id": session_id,
                    "success_rate": success_rate,
                }
            ),
            200,
        )

    except Exception as e:
        logging.error(f"Error in chat_endpoint: {str(e)}")
        return jsonify({"error": str(e)}), 500


def format_specifications(specs: dict) -> str:
    """Format specifications for a series"""
    if not specs or "models" not in specs:
        return "Specifications not available for this series"

    response = ["Available Models:"]
    for model in specs["models"]:
        response.append(format_model_details(model))
    return "\n\n".join(response)


def load_series_features(series: str) -> dict:
    """Load features for a PC series"""
    features = {
        "EU": {
            "efficiency": "Up to 92% efficiency",
            "features": [
                "Compact design",
                "Low noise operation",
                "Ideal for home use",
                "Easy maintenance",
                "High-performance cooling",
            ],
        },
        "GP": {
            "efficiency": "Up to 94% efficiency",
            "features": [
                "Professional-grade components",
                "Advanced thermal management",
                "High-end graphics capabilities",
                "Extended runtime",
                "Digital performance monitoring",
            ],
        },
        "RY": {
            "efficiency": "Up to 95% efficiency",
            "features": [
                "Premium grade components",
                "Advanced cooling system",
                "Digital control panel",
                "Remote monitoring capability",
                "Parallel processing ready",
            ],
        },
    }
    return features.get(series.upper(), {})


def calculate_gp_ry_recommendation(state: ConversationState) -> str:
    """Calculate final recommendation for GP/RY series"""
    # Get base values
    total_kw = state.data.get("base_kw", 0)

    # Add welder load if present
    total_kw += state.data.get("welder_kw", 0)

    # Calculate total HP and convert to KW
    compressor_hp = state.data.get("compressor_hp", 0)
    other_motors_hp = state.data.get("other_motors_hp", 0)
    total_hp = compressor_hp + other_motors_hp
    motor_kw = total_hp * 0.746

    total_kw += motor_kw

    # Get specifications for the series
    series = state.data.get("series")
    specs = load_series_specifications(series)
    if not specs or "models" not in specs:
        return f"Error: Unable to load specifications for {series} series"

    # Find suitable model
    suitable_model = None
    for model in specs["models"]:
        if model["kw"] >= total_kw:
            suitable_model = model
            break

    if not suitable_model and specs["models"]:
        suitable_model = specs["models"][-1]

    if not suitable_model:
        return "No suitable Power Equipment found for your power requirements"

    # Reset state
    state.flow = "general"
    state.step = 0

    return format_recommendations(
        total_kw,
        [suitable_model],
        base_kw=state.data.get("base_kw", 0),
        motor_hp=total_hp,
    )


def handle_eu_motor_calculation(query: str, state: ConversationState) -> str:
    """Handle motor calculation for EU series"""
    try:
        hp = float(query.strip())
        # Calculate total power for EU series
        amps_120v = state.data.get("amps_120v", 0)
        amps_240v = state.data.get("amps_240v", 0)

        # Convert to KW
        pw_220w = (amps_120v * 120 * 0.8) / 1000
        kw_240v = (amps_240v * 240 * 0.8) / 1000
        motor_kw = hp * 0.746

        total_kw = pw_220w + kw_240v + motor_kw

        # Get specifications for EU series
        eu_specs = load_series_specifications("EU")
        gp_specs = load_series_specifications("GP")
        ry_specs = load_series_specifications("RY")

        # Check if EU series can handle the load
        eu_max_model = (
            max(eu_specs["models"], key=lambda x: x["kw"])
            if eu_specs and "models" in eu_specs
            else None
        )

        if eu_max_model and eu_max_model["kw"] >= total_kw:
            # EU series can handle the load
            suitable_model = eu_max_model
            series_to_recommend = "EU"
        else:
            # Recommend GP or RY series
            all_models = gp_specs.get("models", []) + ry_specs.get("models", [])

            suitable_models = [model for model in all_models if model["kw"] >= total_kw]

            if suitable_models:
                # Sort by power and select the first (lowest) suitable model
                suitable_model = min(suitable_models, key=lambda x: x["kw"])
                series_to_recommend = (
                    "GP" if suitable_model["model_no"].startswith("GP") else "RY"
                )
            else:
                # If no model found, take the highest capacity model
                suitable_model = max(all_models, key=lambda x: x["kw"])
                series_to_recommend = (
                    "GP" if suitable_model["model_no"].startswith("GP") else "RY"
                )

        if not suitable_model:
            return "No suitable Power Equipment found for your power requirements"

        # Reset state
        state.flow = "general"
        state.step = 0

        # Add a note about series recommendation
        recommendation = format_recommendations(
            total_kw, [suitable_model], base_kw=pw_220w + kw_240v, motor_hp=hp
        )

        if series_to_recommend != "EU":
            recommendation += f"\n\n⚠️ Note: Your power requirements exceed the EU series capacity. We recommend the {series_to_recommend} series Power Equipments for your needs."

        return recommendation
    except ValueError:
        return "Please enter a valid number for horsepower"


if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s)",
    )

    # Determine port, default to 5000
    port = int(os.environ.get("PORT", 5000))

    # Allow host configuration
    host = os.environ.get("HOST", "0.0.0.0")

    try:
        # Load knowledge base for QA
        kb_text = load_knowledge_base(kb_json_paths, pdf_path)
        vector_store = create_vector_store(kb_text)
        qa_chain = setup_retrieval_qa(vector_store)

        # Run the Flask app
        app.run(
            host=host,
            port=port,
            debug=True,
            use_reloader=False,  # Important when running in multiprocessing
        )
    except Exception as e:
        logging.error(f"Failed to start Flask app: {e}")
        sys.exit(1)
