import os
import sys
import json
import re
from typing import List, Dict, Optional
import time
import logging
import importlib.resources

logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

HF_TOKEN = os.environ.get("HUGGINGFACE_TOKEN")
MODEL_ID = os.environ.get("LLM_MODEL_ID", "mistralai/Mistral-7B-Instruct-v0.3")


# Dynamically import backend functions to reduce coupling
def import_backend_function(function_name):
    try:
        from backend import app

        return getattr(app, function_name)
    except (ImportError, AttributeError) as e:
        logger.error(f"Could not import {function_name}: {e}")
        return None


find_suitable_power_equipment = import_backend_function("find_suitable_power_equipment")
get_model_price = import_backend_function("get_model_price")
calculate_power_needs = import_backend_function("calculate_power_needs")

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from huggingface_hub import login

if HF_TOKEN:
    login(token=HF_TOKEN)


class EquipmentPowerAssistant:
    def __init__(self, model_id=MODEL_ID):
        """
        Initialize the equipment power assistant with a specified LLM
        """
        try:
            self.load_equipment_config()

            self.tokenizer = AutoTokenizer.from_pretrained(model_id)
            self.model = AutoModelForCausalLM.from_pretrained(
                model_id,
                device_map="auto",
                load_in_4bit=True,
                torch_dtype=torch.float16,
            )
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            self.model = None
            self.tokenizer = None

    def load_equipment_config(self, config_path=None):
        """
        Load equipment configuration from a JSON file
        """
        if not config_path:
            config_path = os.path.join(os.path.dirname(__file__), "pc_config.json")

        try:
            with open(config_path, "r") as f:
                self.EQUIPMENT_POWER = json.load(f)
        except FileNotFoundError:
            # Fallback to default configuration
            self.EQUIPMENT_POWER = {
                "gaming": {
                    "watts": 500,
                    "description": "High-performance gaming PC",
                    "cpu_cores": 8,
                    "ram_gb": 32,
                    "gpu": "High-end dedicated GPU",
                    "variants": ["gaming pc", "gaming computer"],
                },
                "workstation": {
                    "watts": 300,
                    "description": "Professional workstation",
                    "cpu_cores": 16,
                    "ram_gb": 64,
                    "gpu": "Professional GPU",
                    "variants": ["work pc", "professional computer"],
                },
                "home_office": {
                    "watts": 100,
                    "description": "Basic home office PC",
                    "cpu_cores": 4,
                    "ram_gb": 16,
                    "gpu": "Integrated graphics",
                    "variants": ["home pc", "office computer"],
                },
                "rendering": {
                    "watts": 600,
                    "description": "3D rendering and video editing PC",
                    "cpu_cores": 32,
                    "ram_gb": 128,
                    "gpu": "Multiple high-end GPUs",
                    "variants": ["render pc", "video editing computer"],
                },
            }
            logger.warning(
                f"Using default PC configuration. Config file not found: {config_path}"
            )

    def advanced_equipment_parsing(self, query: str) -> List[Dict]:
        """Parse PC types from query"""
        query_lower = query.lower()
        detected_equipment = []

        for equipment, details in self.EQUIPMENT_POWER.items():
            if equipment in query_lower:
                detected_equipment.append(
                    {
                        "name": equipment,
                        "watts": details.get("watts", 0),
                        "description": details.get("description", ""),
                        "cpu_cores": details.get("cpu_cores", 0),
                        "ram_gb": details.get("ram_gb", 0),
                    }
                )

        return detected_equipment

    def process_equipment_query(self, query: str) -> Dict:
        """Process PC power and performance query"""
        pc_list = self.advanced_equipment_parsing(query)

        if not pc_list:
            return {
                "status": "error",
                "message": "Could not identify PC type. Please specify gaming, workstation, home office, or rendering PC.",
            }

        power_response = calculate_power_needs(pc_list)

        return {
            "status": "success",
            "equipment": pc_list,
            "recommendation": power_response,
        }

    def generate_detailed_recommendation(self, query: str, power_result: Dict) -> str:
        """
        Generate a detailed, conversational recommendation using LLM

        Args:
            query (str): Original user query
            power_result (Dict): Power calculation results

        Returns:
            str: Detailed LLM-generated recommendation
        """
        if not self.model or not self.tokenizer:
            return power_result.get(
                "recommendation", "Unable to generate detailed recommendation."
            )

        prompt = f"""You are a power equipment expert analyzing a specific power requirement.

User Query: "{query}"

Power Calculation Results:
{json.dumps(power_result, indent=2)}

Task: Provide a comprehensive, conversational recommendation that includes:
1. A detailed breakdown of the equipment power needs
2. Recommended series and specific models
3. Pricing considerations
4. Practical advice for the user's specific scenario
5. Energy efficiency tips
6. Potential cost savings

Your response should be informative, easy to understand, and tailored to the user's specific equipment needs."""

        try:
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
            outputs = self.model.generate(**inputs, max_length=1000)
            llm_response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)

            return llm_response
        except Exception as e:
            logger.error(f"Error generating LLM response: {e}")
            return power_result.get(
                "recommendation", "Unable to generate detailed recommendation."
            )


def main():
    query = os.environ.get("EQUIPMENT_QUERY") or (
        sys.argv[1] if len(sys.argv) > 1 else None
    )

    assistant = EquipmentPowerAssistant()
    power_result = assistant.process_equipment_query(query)
    detailed_recommendation = assistant.generate_detailed_recommendation(
        query, power_result
    )

    log_path = os.environ.get("EQUIPMENT_LOG_PATH", "equipment_power_log.txt")
    try:
        with open(log_path, "a") as log_file:
            log_file.write(f"\n--- Query: {query} ---\n")
            log_file.write("Power Requirements Analysis:\n")
            log_file.write(json.dumps(power_result, indent=2) + "\n")
            log_file.write("\nDetailed Recommendation:\n")
            log_file.write(detailed_recommendation + "\n")
    except Exception as e:
        logger.error(f"Error logging results: {e}")

    return {
        "power_result": power_result,
        "detailed_recommendation": detailed_recommendation,
    }


if __name__ == "__main__":
    main()

    main()
