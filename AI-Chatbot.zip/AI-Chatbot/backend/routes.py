import os
import sys
import subprocess
import signal
import logging
import multiprocessing
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def run_app(script_name):
    """Run a Python script with environment setup"""
    try:
        # Ensure we're in the correct directory
        backend_dir = os.path.dirname(os.path.abspath(__file__))
        os.chdir(backend_dir)

        # Set environment variables
        env = os.environ.copy()
        env["PYTHONPATH"] = backend_dir
        env["FLASK_ENV"] = "development"

        # Run the script
        logger.info(f"Starting {script_name}...")
        subprocess.run([sys.executable, script_name], env=env, check=True)
    except Exception as e:
        logger.error(f"Error running {script_name}: {e}")


def run_distinct_app(query=None):
    """Run the distinct application with an optional query"""
    try:
        backend_dir = os.path.dirname(os.path.abspath(__file__))
        os.chdir(backend_dir)

        env = os.environ.copy()
        if query:
            env["QUERY"] = query

        subprocess.run([sys.executable, "distinct.py"], env=env, check=True)
    except Exception as e:
        logger.error(f"Error running distinct app: {e}")


def route_equipment_query(query):
    """Route equipment-based queries to distinct.py"""
    try:
        distinct_process = multiprocessing.Process(
            target=run_distinct_app, args=(query,)
        )
        distinct_process.start()
        distinct_process.join()
    except Exception as e:
        logger.error(f"Error routing equipment query: {e}")


def main():
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Create process pool
    processes = []

    try:
        # Create and start Flask app process
        flask_process = multiprocessing.Process(target=run_app, args=("app.py",))
        flask_process.start()
        processes.append(flask_process)

        # Create and start distinct app process
        distinct_process = multiprocessing.Process(target=run_distinct_app)
        distinct_process.start()
        processes.append(distinct_process)

        # Wait for processes to complete
        while True:
            # Check if any process has terminated
            for p in processes:
                if not p.is_alive():
                    logger.warning(f"Process {p.name} has terminated unexpectedly.")

            # Small sleep to prevent high CPU usage
            time.sleep(1)

    except KeyboardInterrupt:
        logger.info("Interrupted by user. Shutting down...")
    finally:
        # Terminate all processes
        for p in processes:
            if p.is_alive():
                p.terminate()
                p.join()


def signal_handler(signum, frame):
    """Handle interrupt signals to gracefully stop processes"""
    logger.info("Received interrupt signal. Shutting down...")
    sys.exit(0)


if __name__ == "__main__":
    # Ensure the script can be run from any directory
    backend_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, backend_dir)

    # Set environment variables if needed
    os.environ["FLASK_ENV"] = "development"
    os.environ["PYTHONPATH"] = backend_dir

    main()
