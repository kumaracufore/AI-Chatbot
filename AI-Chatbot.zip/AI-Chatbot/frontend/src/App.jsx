import { useState, useEffect, useRef } from "react";
import "./App.css";
import axios from "axios";

// API configuration
const API_BASE_URL = `http://${window.location.hostname}:5000`;

function App() {
  const [userQuery, setUserQuery] = useState("");
  const [chatHistory, setChatHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const chatContainerRef = useRef(null);
  const [equipmentList, setEquipmentList] = useState([]);
  const [response, setResponse] = useState({
    type: "initial",
    message: "",
    example: "",
  });

  // Scroll to bottom when chat history updates
  useEffect(() => {
    if (chatContainerRef.current) {
      const { scrollHeight } = chatContainerRef.current;
      chatContainerRef.current.scrollTo({
        top: scrollHeight,
        behavior: "smooth",
      });
    }
  }, [chatHistory]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const userEntry = { role: "user", content: userQuery };

    try {
      // Add the user message immediately
      setChatHistory((prevHistory) => [...prevHistory, userEntry]);

      // Convert chat history to the format expected by the backend
      const formattedHistory = chatHistory.map((entry) => ({
        role: entry.role,
        content: entry.content,
      }));

      const response = await fetch(`${API_BASE_URL}/api/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        mode: "cors",
        credentials: "omit",
        body: JSON.stringify({
          query: userQuery,
          history: formattedHistory,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Failed to fetch response. Please try again."
        );
      }

      // Create the assistant response
      const assistantEntry = {
        role: "assistant",
        content: data.response || "",
      };

      // Simulate a 0.05-second delay before updating the chat history
      setTimeout(() => {
        setChatHistory((prevHistory) => [...prevHistory, assistantEntry]);
        setLoading(false);
      }, 5);
    } catch (error) {
      console.error("Error:", error);
      setError(error.message || "Failed to fetch response. Please try again.");
      setLoading(false);
    } finally {
      setUserQuery("");
    }
  };

  const formatResponse = (response) => {
    return response.split("\n").map((line, index) => {
      // Check for URLs in the line
      const urlMatch = line.match(/(?:Product page:|https?:\/\/[^\s]+)/);
      if (urlMatch) {
        const url = urlMatch[0].startsWith("http")
          ? urlMatch[0]
          : line.split(": ")[1];
        // Remove trailing period from URL if it exists
        const cleanUrl = url.replace(/\.$/, "");
        if (line.startsWith("Product page:")) {
          return (
            <p key={index}>
              Product page:{" "}
              <a href={cleanUrl} target="_blank" rel="noopener noreferrer">
                {cleanUrl}
              </a>
            </p>
          );
        } else {
          return <p key={index}>{line}</p>;
        }
      } else if (line.match(/^\d+\./)) {
        return <li key={index}>{line.replace(/^\d+\./, "").trim()}</li>;
      } else {
        return <p key={index}>{line}</p>;
      }
    });
  };

  const handleEquipmentPowerCalculation = async () => {
    try {
      // First, validate input
      if (!equipmentList.length) {
        setResponse({
          type: "error",
          message: "Please add at least one piece of equipment.",
        });
        return;
      }

      const payload = {
        equipment: equipmentList.map((item) => ({
          name: item.name,
          quantity: item.quantity,
        })),
      };

      const response = await axios.post("/api/equipment-power", payload);

      // Handle different response statuses
      switch (response.data.status) {
        case "initial_query":
          // Prompt user for more details
          setResponse({
            type: "interactive",
            message: response.data.message,
            example: response.data.example,
          });
          break;

        case "recommendation":
          // Detailed power calculation and generator recommendation
          const powerBreakdown = response.data.power_breakdown;
          const recommendedGenerators = response.data.recommended_generators;

          setResponse({
            type: "recommendation",
            equipment: response.data.equipment,
            powerBreakdown: {
              electricalLoadWatts: powerBreakdown.electrical_load_watts,
              electricalLoadKw: powerBreakdown.electrical_load_kw,
              motorHp: powerBreakdown.motor_hp,
              motorLoadKw: powerBreakdown.motor_load_kw,
              totalLoadKw: powerBreakdown.total_load_kw,
              recommendedKwWithMargin:
                powerBreakdown.recommended_kw_with_margin,
            },
            generators: recommendedGenerators.map((gen) => ({
              model: gen.model,
              continuousPowerKw: gen.continuous_power_kw,
              surgePowerKw: gen.surge_power_kw,
              voltage: gen.voltage,
              fullLoadAmps: gen.full_load_amps,
              pricing: gen.pricing,
              recommendedReason: gen.recommended_reason,
            })),
          });
          break;

        case "error":
          setResponse({
            type: "error",
            message: response.data.message,
          });
          break;

        default:
          setResponse({
            type: "error",
            message: "Unexpected response from server",
          });
      }
    } catch (error) {
      console.error("Equipment power calculation error:", error);
      setResponse({
        type: "error",
        message:
          error.response?.data?.message || "An unexpected error occurred",
      });
    }
  };

  return (
    <div className="chat-container">
      <h1>AI Assistant</h1>
      <div className="chat-history" ref={chatContainerRef}>
        {chatHistory.map((entry, index) => (
          <div key={index} className={`chat-entry ${entry.role}`}>
            <strong>{entry.role === "user" ? "You" : "Assistant"}:</strong>
            <div className="chat-content">
              {entry.role === "assistant"
                ? formatResponse(entry.content)
                : entry.content}
            </div>
          </div>
        ))}
      </div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={userQuery}
          onChange={(e) => setUserQuery(e.target.value)}
          placeholder="Type your query here..."
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? "Loading..." : "Send"}
        </button>
      </form>
      {error && <p className="error-message">{error}</p>}
      {response.type === "interactive" && (
        <div className="interactive-response">
          <p>{response.message}</p>
          {response.example && (
            <div className="example-payload">
              <pre>{JSON.stringify(response.example, null, 2)}</pre>
            </div>
          )}
        </div>
      )}

      {response.type === "recommendation" && (
        <div className="power-recommendation">
          <h3>Power Requirements Analysis</h3>

          <div className="equipment-details">
            <h4>Equipment Breakdown</h4>
            {response.equipment.map((item, index) => (
              <div key={index} className="equipment-item">
                <span>
                  {item.name} (x{item.quantity})
                </span>
                <span>{item.watts} watts</span>
              </div>
            ))}
          </div>

          <div className="power-breakdown">
            <h4>Power Calculation</h4>
            <table>
              <tbody>
                <tr>
                  <td>Electrical Load:</td>
                  <td>
                    {response.powerBreakdown.electricalLoadWatts} watts (
                    {response.powerBreakdown.electricalLoadKw.toFixed(2)} KW)
                  </td>
                </tr>
                <tr>
                  <td>Motor Load:</td>
                  <td>
                    {response.powerBreakdown.motorHp} HP (
                    {response.powerBreakdown.motorLoadKw.toFixed(2)} KW)
                  </td>
                </tr>
                <tr>
                  <td>Total Load:</td>
                  <td>{response.powerBreakdown.totalLoadKw.toFixed(2)} KW</td>
                </tr>
                <tr>
                  <td>Recommended Capacity (20% margin):</td>
                  <td>
                    {response.powerBreakdown.recommendedKwWithMargin.toFixed(2)}{" "}
                    KW
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="generator-recommendations">
            <h4>Recommended Generators</h4>
            {response.generators.map((gen, index) => (
              <div key={index} className="generator-card">
                <h5>{gen.model} Generator</h5>
                <div className="generator-details">
                  <p>Continuous Power: {gen.continuousPowerKw} KW</p>
                  <p>Surge Power: {gen.surgePowerKw} KW</p>
                  <p>Voltage: {gen.voltage}V</p>
                  <p>Full Load Amps: {gen.fullLoadAmps} A</p>
                  <p className="recommendation-reason">
                    {gen.recommendedReason}
                  </p>

                  <div className="pricing">
                    <h6>Pricing</h6>
                    {gen.pricing.usd && (
                      <p>USD: ${gen.pricing.usd.toLocaleString()}</p>
                    )}
                    {gen.pricing.cad && (
                      <p>CAD: ${gen.pricing.cad.toLocaleString()}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
